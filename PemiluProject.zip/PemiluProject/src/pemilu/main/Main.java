/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pemilu.main;

import java.io.IOException;
import pemilu.gui.Frame;
import pemilu.gui.HasilPemilu;

/**
 *
 * @author K6
 */
public class Main {
    public static void main(String[] args) throws IOException {
        HasilPemilu test = new HasilPemilu();
        test.setVisible(true);
        Frame frame = new Frame();
        frame.setExtendedState(Frame.MAXIMIZED_BOTH);
        frame.setVisible(true);
    }
}
