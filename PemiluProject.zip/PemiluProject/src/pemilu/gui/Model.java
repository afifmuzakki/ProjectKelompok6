/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pemilu.gui;

/**
 *
 * @author K6
 */
public class Model {
    private String lokasi;
    private int suara;

    /**
     * @return the lokasi
     */
    public String getLokasi() {
        return lokasi;
    }

    /**
     * @param lokasi the lokasi to set
     */
    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }

    /**
     * @return the suara
     */
    public int getSuara() {
        return suara;
    }

    /**
     * @param suara the suara to set
     */
    public void setSuara(int suara) {
        this.suara = suara;
    }
}
